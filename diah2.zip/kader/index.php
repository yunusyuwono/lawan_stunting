<?php include "nav.php";?>
<div class="container mt-2">
	<div class="card">
		<div class="card-body bg-mute">
			<h4>Selamat Datang Kader <?=$u['nama'];?> </h4>
		</div>
	</div>
</div>
<?php include "foot.php";?>