// check if IE10 or older
if (navigator.appVersion.indexOf('MSIE') > -1) {
  alert('This WebViewer version is not supported in your browser. We will now open an FAQ page describing how to setup WebViewer for old IE versions.');
  window.open('https://www.pdftron.com/documentation/web/faq/webviewer-with-ie9/');
}
