/* eslint-disable-next-line no-unused-vars */
function samplesSetup(instance) {
  instance.UI.enableElements(['bookmarksPanel', 'bookmarksPanelButton', 'richTextPopup']);
  instance.UI.enableFeatures([instance.UI.Feature.Measurement]);
}
